import 'dart:async';
import 'package:flutter/material.dart';
import 'autorization_screen.dart';
import 'content/app_theme.dart' as AppColor;

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(
        Duration(seconds: 1),
        () => Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (BuildContext context) => LoginPage())));
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          constraints: BoxConstraints.expand(height: double.infinity),
          child: Image(
            image: AssetImage(
              'assets/images/lilar_splash_screen.png',
            ),
            fit: BoxFit.cover,
          ),
        ),
      ),
    );
  }
}
