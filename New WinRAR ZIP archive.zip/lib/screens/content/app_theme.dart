import 'dart:ui';
import 'package:flutter/material.dart';

final Color color1 = Color(0xff5c6f52);
final Color color2 = Color(0xfff2f4ef);
final Color color3 = Color(0xffffffff);


